from django.apps import AppConfig


class DjangoAppConfig(AppConfig):
    name = 'Django_App'
