from django.shortcuts import render
from django.http import httpResponse

def index(request):
    return httpResponse('''Welcome to your first Django App''')

