from django.apps import AppConfig


class EdurekaCalConfig(AppConfig):
    name = 'edureka_cal'
