from  example_pkg.example import mult

print(mult(7, 6))
