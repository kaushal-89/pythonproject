def mult(*args):
    val = 1
    for a in args:
        val = val * a

    return val