import sqlite3

try:
    conn = sqlite3.connect("data.db")
    print("Opened Data DB file")
    cursor = conn.cursor()
    # cursor.execute('''
    #                 create table employees
    #                 (ID PRIMARY KEY NOT NULL, NAME TEXT NOT NULL,
    #                 AGE INT, ADDRESS VARCHAR(100))'''
    #                )
    # print("Table creation complete")
    cursor.execute('''
    INSERT INTO employees values (5, "Saurabh", 32, "Delhi")
    ''')
    print(cursor.lastrowid)

    # cursor.execute('''
    #     INSERT INTO employees values (2, "Raman", 25, "Punjab")
    #     ''')
    #
    # cursor.executemany('''
    #     INSERT INTO employees values (?, ?, ?, ?)''',
    #                    [(3, "Shobhit", 45, "MP"), (4, "Heena", 32, "Rajasthan")]
    #                    )
    # cursor.execute('''
    #         UPDATE employees set name = ? where id = ?''',
    #                ('Priya', 2)
    #          )
    # conn.commit()
    # res = cursor.execute("SELECT * from employees")
    # header = {0: "ID", 1: "NAME", 2: "AGE", 3: "PLACE"}
    # for row in res:
    #     for head in header:
    #         print(f"{header[head]} is {row[head]}")
    #     print("*" * 100)
    #
    # data = cursor.execute("SELECT * from employees where name = ?", ('Saurabh', ))
    # print(data.fetchone())

    #print("Record updated successfully")
    # cursor.execute("DELETE FROM employees where name = ?", ("Heena",))
    conn.commit()
    conn.close()
    print("Record deleted successfully")
except (Exception, sqlite3.Error) as err:
    print(f"Error while creating or connecting to DB : {err}")

