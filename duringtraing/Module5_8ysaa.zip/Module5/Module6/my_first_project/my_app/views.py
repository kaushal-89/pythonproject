from django.http import HttpResponse
import datetime

def index(request):
    return HttpResponse(f"<h1>Welcome to my first application in Django. Date is : {datetime.datetime.now()}</h1>")
