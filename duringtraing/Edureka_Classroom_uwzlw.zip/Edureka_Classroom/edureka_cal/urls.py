from django.urls import path, include, re_path
from .views import index, contact


urlpatterns = [
    # path('<int:year>/<int:month>/', index, name='flex_cal'),
    re_path(r'^(?P<year>[0-9]{4})/(?P<month>0?[1-9]|1[0-2])/', index, name='flex_cal' ),
    path('', index, name='index'),
    path('contact/', contact, name='cotactus')
]
