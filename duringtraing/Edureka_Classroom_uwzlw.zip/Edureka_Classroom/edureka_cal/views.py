from django.contrib.auth.decorators import login_required
from django.core.mail import send_mail, get_connection
from django.shortcuts import render, HttpResponseRedirect
from datetime import date
import calendar
from calendar import HTMLCalendar
from .forms import ContactForm


def getcal(month, year):
    return HTMLCalendar().formatmonth(year, month)

@login_required
def index(request, year=date.today().year, month=date.today().month):

    year = int(year)
    month = int(month)
    if year < 1990 or year > 2020:
        year = date.today().year

    month_name = calendar.month_name[month]
    title = f"Edureka course calendar for {month_name} - {year}"

    cal = getcal(month, year)
    #HTMLCalendar().formatmonth(year, month)

    announcements = [
        {'date': '15-09-2020', 'announcement': "Django course registration open"},
        {'date': '25-09-2020', 'announcement': "Django course starts"}
    ]

    return render(request, 'edureka_cal/calendar_base.html', {'title': title, 'cal': cal, 'announcements': announcements})


def contact(request):
    submitted = False
    if request.method == "POST":
        form = ContactForm(request.POST)
        if form.is_valid():
            cd = form.cleaned_data
            print(cd)
            name = cd['yourname']
            message = cd['message']
            con = get_connection('django.core.mail.backends.console.EmailBackend')
            send_mail(
            cd['subject'],
            cd['message'],
            cd.get('email', 'saurabh@django.com'),
            ['st@django.com'],
            connection=con)

            return HttpResponseRedirect('/cal')

    else:
        form = ContactForm()

    return render(request, 'edureka_cal/contact_form.html', {'form': form})