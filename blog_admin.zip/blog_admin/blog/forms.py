from django import forms

class CommentForm(forms.Form):
    yourname = forms.CharField(max_length=100, label="Name")
    comment = forms.CharField(widget=forms.Textarea)