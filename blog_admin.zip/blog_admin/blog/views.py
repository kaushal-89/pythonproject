from django.http import HttpResponse, JsonResponse
from django.views import generic
from .models import Article, Comment
from django.core import serializers
from rest_framework.views import APIView
from rest_framework.response import Response
from .serializer import CommentSerializer

# Create your views here.

def index(request):
    text = 'This is my first blog'
    return HttpResponse(text)

class ArticleListView(generic.ListView):
    model = Article

class ArticleDetailView(generic.DetailView):
    model = Article

def add_comment(request):
    authorname = request.GET.get('authorname', None)
    comment = request.GET.get('comment', None)
    article = request.GET.get('article', None)

    c = Comment(name=authorname, comment=comment, article=article)
    c.save()

    return JsonResponse('true')

class Comment_API(APIView):
    def get(self, request):
        #comment = Comment.objects.all()
        comment = Comment.objects.filter().select_related()
        #print(comment)
        #print(str(comment.query))
        data = CommentSerializer(comment, many=True)
        return Response(data.data)