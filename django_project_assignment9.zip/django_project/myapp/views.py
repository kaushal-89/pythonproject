from django.shortcuts import render
from django.http import HttpResponse, HttpResponseRedirect
from datetime import date
import calendar
from calendar import HTMLCalendar
from .forms import ContactForm


def index(request):
    txt = '''This is my first django project'''
    return HttpResponse(txt)

# Create your views here.

def contactus(request):
    return HttpResponse('''This is contact us page''')

def aboutus(request):
    return HttpResponse('''This is about us page''')

def cal(request, year=date.today().year, month = date.today().month):
    year = int(year)
    month = int(month)
    if year < 1998 or year > 2020:
        year = date.today().year

    month_name = calendar.month_name[month]
    title = f"Website page calendar for {month_name} - {year}"
    cal = HTMLCalendar().formatmonth(year, month)

    announcement = [
        {'date': '15-09-02020', 'announcement':'Django course registration open'},
        {'date': '25-09-02020', 'announcement': 'Django course start'}
    ]
    #return render(request, 'base.html', {'title': title, 'cal': cal })
    return render(request, 'edureka_cal/edureka_base.html', {'title': title, 'cal': cal, 'announcements': announcement})

def contact(request):
    submitted = False
    if request.method == "POST":
        form = ContactForm(request.POST)
        if form.is_valid():
            cd = form.cleaned_data
            print(cd)
            return HttpResponseRedirect('/cal')

    else:
        form = ContactForm()
    return render(request, 'edureka_cal/contact_form.html',{'form': form})
