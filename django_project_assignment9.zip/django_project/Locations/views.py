from django.shortcuts import render
from django.views import View
from django.views import generic
from .models import Location
from django.http import JsonResponse
from django.core import serializers
from rest_framework.views import APIView
from rest_framework.response import Response
from .serializer import LocationSerializer
from rest_framework.generics import RetrieveAPIView, RetrieveDestroyAPIView, ListCreateAPIView, RetrieveUpdateAPIView


# Create your views here.

def location_api(request):
    all_location = Location.objects.all()
    return JsonResponse(serializers.serialize("json", all_location), safe=False)

class HelloView(APIView):

    def get(self, request):
        return Response({'message': "This is my first API in rest framework"})

class Location_API(APIView):
    def get(self,  request):
        location = Location.objects.all()
        data = LocationSerializer(location, many=True)
        return Response(data.data)

class LocationDetail(RetrieveAPIView):
    queryset = Location.objects.all()
    serializer_class = LocationSerializer

class Create_location(ListCreateAPIView):
    queryset = Location.objects.all()
    serializer_class = LocationSerializer

class Location_delete(RetrieveDestroyAPIView):
    queryset = Location.objects.all()
    serializer_class = LocationSerializer

class Update_Location(RetrieveUpdateAPIView):
    queryset = Location.objects.all()
    serializer_class = LocationSerializer


