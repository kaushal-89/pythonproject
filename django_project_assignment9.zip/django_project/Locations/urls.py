from django.urls import path
from .views import location_api, HelloView, Location_API, LocationDetail, Create_location, Location_delete, Update_Location

urlpatterns = [
    path('location/', location_api, name='location'),
    path('test_view/', HelloView.as_view(), name='HelloView'),
    path('location_api/', Location_API.as_view(), name='Location_api'),
    path('location_detail/<int:pk>/', LocationDetail.as_view(), name='LocationDetail'),
    path('add_location/', Create_location.as_view(), name='Create_location'),
    path('delete_location/<int:pk>/', Location_delete.as_view(), name='location_delete'),
    path('update_location/<int:pk>/', Update_Location.as_view(), name='update_location'),
]