from django.contrib import admin
from .models import Location

# Register your models here.
class LocationAdmin(admin.ModelAdmin):
    fields = ['city', 'country', 'added_date']
    list_display = ('city', 'country', 'added_date')
    list_filter = ['city', 'country']
    search_fields = ['city', 'country']


admin.site.register(Location, LocationAdmin)


