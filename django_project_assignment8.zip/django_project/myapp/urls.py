from django.urls import path, re_path

from .views import index, contactus, aboutus, cal, contact

urlpatterns = [
    path('', index, name='index'),
    path('contactus/', contactus, name='contact'),
    path('about-us/', aboutus, name='aboutus'),
    path('cal/', cal, name='cal'),
    #path('cal/<int:year>/<int:month>/', cal, name='flex_cal'),
    re_path(r'^cal/(?P<year>[0-9]{4})/(?P<month>0?[1-9]|1[1-2])', cal, name='flex_cal'),
    path('cal/contact/', contact, name='calconact'),
]